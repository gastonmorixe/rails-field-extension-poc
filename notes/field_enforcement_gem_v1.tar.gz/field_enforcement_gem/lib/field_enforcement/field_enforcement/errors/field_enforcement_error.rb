module FieldEnforcement
  module Errors
    class FieldEnforcementError < StandardError; end
  end
end
