module FieldEnforcement
  module Errors
    class FieldEnforcementUnknownTypeError < FieldEnforcementError; end
  end
end
