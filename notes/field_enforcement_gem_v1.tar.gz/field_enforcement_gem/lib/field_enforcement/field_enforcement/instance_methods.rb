module FieldEnforcement
  module InstanceMethods
  end
end
